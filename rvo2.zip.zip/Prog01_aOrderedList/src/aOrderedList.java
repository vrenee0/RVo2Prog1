//891556910, Renee, rvo2@lsu.edu
import java.util.Arrays;
import java.util.NoSuchElementException;

public class aOrderedList {
    private final int SIZE_INCREMENTS = 20;
    private Cars[] oList; // the ordered list of cars objects
    private int listSize; // the current size of list
    private int numObjects; // the number of objects in the list
    private int current; // pointer for iteration through the list
    private Comparable<?> element; // the current element during iteration
    
    public aOrderedList() {
        numObjects = 0;
        listSize = SIZE_INCREMENTS;
        oList = new Cars[listSize];
        this.current = 0;
        this.element = null;
    }
    //method to ass a new cars object to list(stays sorted)
    public void add(Cars newCar) {
        if (numObjects == listSize) {
            listSize += SIZE_INCREMENTS;
            oList = Arrays.copyOf(oList, listSize);
        }
        
        int index = 0;
        while (index < numObjects && newCar.compareTo(oList[index]) > 0) {
            index++;
        }

        System.arraycopy(oList, index, oList, index + 1, numObjects - index);
        oList[index] = newCar;
        numObjects++;
    }
    //method to generate a string representation of the list
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        for (int i = 0; i < numObjects; i++) {
            sb.append(oList[i]);
            if (i < numObjects - 1) {
                sb.append(", ");
            }
        }
        sb.append("]");
        return sb.toString();
    }
    //method to get the size of the list
    public int size() {
        return numObjects;
    }
    //method to get an element at a specific index
    public Comparable<?> get(int index) {
        return oList[index];
    }
    //method to check if list is empty
    public boolean isEmpty() {
        return numObjects == 0;
    }
    //method to remove a cars object from the list by make and year
    public void remove(String make, int year) {
        int index = -1;
        for (int i = 0; i < numObjects; i++) {
            if (oList[i] != null && oList[i].getMake().equals(make) && oList[i].getYear() == year) {
                index = i;
                break;
            }
        }
        if (index != -1) {
            System.arraycopy(oList, index + 1, oList, index, numObjects - index - 1);
            numObjects--;
        }
    }
    //method to reset the iteration
    public void reset() {
        current = 0;
    }
    //method to get the next element during iteration
    public Comparable<?> next() {
        if (!hasNext()) {
            throw new NoSuchElementException();
        }
        element = oList[current++];
        return element;
    }
    //method to check if there are more elements during iteration
    public boolean hasNext() {
        return current < numObjects;
    }
    //method to remove cars from the list by index
    public void remove(int index) {
        if (index < 0 || index >= numObjects) {
            throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + numObjects);
        }
        System.arraycopy(oList, index + 1, oList, index, numObjects - index - 1);
        numObjects--;
    }
}