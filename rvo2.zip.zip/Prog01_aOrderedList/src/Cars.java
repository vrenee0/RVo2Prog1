//891556910, Renee, rvo2@lsu.edu

public class Cars implements Comparable<Cars> {
	private String make;
	private int year;
	private int price;
	
	public Cars(String Make, int Year, int Price) {
		this.make = Make;
		this.year = Year;
		this.price = Price;
	}	
		//returns value of make
	public String getMake() {
		return make;
	}
	//returns value of year
	public int getYear() {
		return year;
	}
	//returns value of price
	public int getPrice() {
		return price;
	}
	public int compareTo(Cars other) {
		if(Integer.compare(price, other.price)!= 0) 
			return Integer.compare(price, other.price);
		else 
			return Integer.compare(year, other.year);
			
	}
	public void printInfo() {
		System.out.println("Make: " + make + ", Year: " + year + ", Price: $" + price);
	
	}
}
