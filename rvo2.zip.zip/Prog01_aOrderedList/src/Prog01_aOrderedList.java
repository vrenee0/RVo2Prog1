//891556910, Renee, rvo2@lsu.edu
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Prog01_aOrderedList {
	//Create a scanner object to read input from the user
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Scanner inputFileScanner = null;
        PrintWriter outputFileWriter = null;

        try {
        	//Get input filename from the user
            String inputFilename = getInputFilename(scanner, "Enter input filename: ");
            File inputFile = new File(inputFilename);
            inputFileScanner = new Scanner(inputFile);
            
            //Create an instance to store car objects
            aOrderedList aOrderedList = new aOrderedList();
            
            //Read car info from input file and fill list
            while (inputFileScanner.hasNextLine()) {
                String carInfo = inputFileScanner.nextLine();
                String[] carString = carInfo.split(",");
                if (carString[0].equals("A")) {
                    String make = carString[1];
                    int year = Integer.parseInt(carString[2]);
                    int price = Integer.parseInt(carString[3]);
                    Cars carObject = new Cars(make, year, price);
                    aOrderedList.add(carObject);
                } else if (carString[0].equals("D")) {
                    String make = carString[1];
                    int year = Integer.parseInt(carString[2]);
                    aOrderedList.remove(make, year);
                }
            }
            //get output filename
            String outputFilename = getOutputFilename(scanner, "Enter output filename: ");
            outputFileWriter = new PrintWriter(outputFilename);
            outputFileWriter.println("Number of cars: " + aOrderedList.size());
            //write car info to the output file
            for (int i = 0; i < aOrderedList.size(); i++) {
                outputFileWriter.println();
                Comparable<?> carInfo = aOrderedList.get(i);
                if (carInfo != null) {
                    Cars car = (Cars) carInfo;
                    outputFileWriter.printf("Make:\t%s\nYear:\t%d\nPrice:\t$%,d%n", car.getMake(), car.getYear(), car.getPrice());
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + e.getMessage());
        } finally {
            if (inputFileScanner != null) {
                inputFileScanner.close();
            }
            if (outputFileWriter != null) {
                outputFileWriter.close();
            }
            scanner.close();
        }
    }
    //method to get input filename
    public static String getInputFilename(Scanner scanner, String userPrompt) {
        String filename;
        do {
            System.out.print(userPrompt);
            filename = scanner.nextLine();
            File file = new File(filename);
            if (file.exists()) {
                return filename;
            } else {
                System.out.println("File " + filename + " does not exist. Would you like to try again? <Y/N>");
                String option = scanner.nextLine();
                if (option.equalsIgnoreCase("N")) {
                    System.out.println("Exiting program.");
                    System.exit(0);
                }
            }
        } while (true);
    }
    //method to get output file name
    public static String getOutputFilename(Scanner scanner, String userPrompt) {
        String filename;
        do {
            System.out.print(userPrompt);
            filename = scanner.nextLine();
            File file = new File(filename);
            if (!file.exists()) {
                return filename;
            } else {
                System.out.println("File " + filename + " already exists. Would you like to try again? <Y/N>");
                String option = scanner.nextLine();
                if (option.equalsIgnoreCase("N")) {
                    System.out.println("Exiting program.");
                    System.exit(0);
                }
            }
        } while (true);
    }
}